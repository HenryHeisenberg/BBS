package com.Jiege.DBUtil;

import java.util.HashMap;
import java.util.Map;

import com.Jiege.modle.User;

public class DBUtil {
	private static Map<String, User> db = new HashMap<String, User>();
	//数据字典
	public static boolean addInfor (String username,String password) {
		if(db.containsKey(username)){
			return false;
		}else {
			User user = new User(username, password);
			db.put(username, user);
			return true;
		}
	}
	//处理登陆请求
	public static User verifyAccount(String username,String password) {
		if(db.containsKey(username)) { //数据字典中用户名存在
			User user = db.get(username); 
			if(user.getPassword().equals(password)) //核对用户名的密码是否正确
				return user; //密码正确返回账户
		}else {
			return null; //密码错误返回�?
		}
			return null;  //用户名不存在返回�?
	}
}
